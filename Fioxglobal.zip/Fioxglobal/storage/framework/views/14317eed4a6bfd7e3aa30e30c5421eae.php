
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Welcome to the Admin Dashboard</h1>
        <p>This is the admin dashboard where you can manage your application.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Fiox_Global\Fioxglobal\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>