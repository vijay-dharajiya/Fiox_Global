
<?php $__env->startSection('content'); ?>

<style>
    :root {
        --fiox-amber: #B8791F;
        --fiox-amber-dark: #8F5F16;
        --fiox-charcoal: #2F2F30;
        --fiox-bg: #FAF8F5;
        --fiox-border: #EDE6DA;
    }

    .inq-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 22px;
    }

    .inq-header h4 {
        color: var(--fiox-charcoal);
        font-weight: 700;
        margin: 0;
    }

    .inq-header span {
        color: #8a8a8a;
        font-size: 0.85rem;
    }

    .inq-card {
        background: #fff;
        border: 1px solid var(--fiox-border);
        border-radius: 14px;
        overflow: hidden;
    }

    .table-inquiries {
        margin: 0;
    }

    .table-inquiries thead th {
        background: var(--fiox-bg);
        color: var(--fiox-amber-dark);
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        border-bottom: 1px solid var(--fiox-border);
        padding: 14px 16px;
        white-space: nowrap;
    }

    .table-inquiries tbody td {
        padding: 14px 16px;
        font-size: 0.88rem;
        color: var(--fiox-charcoal);
        border-bottom: 1px solid var(--fiox-border);
        vertical-align: top;
    }

    .table-inquiries tbody tr:last-child td {
        border-bottom: none;
    }

    .table-inquiries tbody tr:hover {
        background: var(--fiox-bg);
    }

    .badge-product {
        display: inline-block;
        background: rgba(184, 121, 31, 0.1);
        color: var(--fiox-amber-dark);
        font-size: 0.75rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 20px;
    }

    .desc-cell {
        max-width: 260px;
        white-space: normal;
        color: #6b6b6b;
        font-size: 0.85rem;
        line-height: 1.5;
    }

    .empty-row td {
        text-align: center;
        padding: 50px 16px;
        color: #8a8a8a;
        font-size: 0.9rem;
    }
</style>

<div class="inq-header">
    <h4>Product Inquiries</h4>
    <span><?php echo e($inquiries->count()); ?> total</span>
</div>

<div class="inq-card">
    <div class="table-responsive">
        <table class="table table-inquiries">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Full Name</th>
                    <th>Company</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Product</th>
                    <th>Description</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($inquiry->full_name); ?></td>
                        <td><?php echo e($inquiry->company_name ?: '-'); ?></td>
                        <td><a href="tel:<?php echo e($inquiry->phone); ?>" style="color: var(--fiox-charcoal); text-decoration: none;"><?php echo e($inquiry->phone); ?></a></td>
                        <td>
                            <?php if($inquiry->email): ?>
                                <a href="mailto:<?php echo e($inquiry->email); ?>" style="color: var(--fiox-charcoal); text-decoration: none;"><?php echo e($inquiry->email); ?></a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($inquiry->product): ?>
                                <span class="badge-product"><?php echo e($inquiry->product->name); ?></span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="desc-cell"><?php echo e($inquiry->description ?: '-'); ?></td>
                        <td><?php echo e($inquiry->created_at->format('d M Y')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="empty-row">
                        <td colspan="8">No inquiries received yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Fiox_Global\Fioxglobal\resources\views/admin/inquery.blade.php ENDPATH**/ ?>